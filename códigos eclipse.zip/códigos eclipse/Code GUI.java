import javax.swing.*;
import java.awt.*;

public class GUI extends JFrame {

    private static final long serialVersionUID = 1L;
    private ICaixaEletronico caixa;

    public GUI(Class<?> classeCaixa) {
        try {
            caixa = (ICaixaEletronico) classeCaixa.getDeclaredConstructor().newInstance();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao criar o caixa eletrônico.");
        }

        setTitle("Caixa eletrônico");
        setSize(260, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(9, 1, 5, 5));

        JLabel cliente = new JLabel("Módulo do Cliente:");
        JButton btnSaque = new JButton("Efetuar Saque");

        JLabel administrador = new JLabel("Módulo do Administrador:");
        JButton btnRelatorio = new JButton("Relatório de Cédulas");
        JButton btnValorTotal = new JButton("Valor total disponível");
        JButton btnReposicao = new JButton("Reposição de Cédulas");
        JButton btnCotaMinima = new JButton("Cota Mínima");

        JLabel ambos = new JLabel("Módulo de Ambos:");
        JButton btnSair = new JButton("Sair");

        add(cliente);
        add(btnSaque);
        add(administrador);
        add(btnRelatorio);
        add(btnValorTotal);
        add(btnReposicao);
        add(btnCotaMinima);
        add(ambos);
        add(btnSair);

        btnSaque.addActionListener(e -> efetuarSaque());
        btnRelatorio.addActionListener(e -> mostrarMensagem(caixa.pegaRelatorioCedulas()));
        btnValorTotal.addActionListener(e -> mostrarMensagem(caixa.pegaValorTotalDisponivel()));
        btnReposicao.addActionListener(e -> reporCedulas());
        btnCotaMinima.addActionListener(e -> definirCotaMinima());
        btnSair.addActionListener(e -> {
            CaixaEletronico caixaReal = (CaixaEletronico) caixa;
            mostrarMensagem(caixaReal.pegarHistorico());
            System.exit(0);
        });
    }

    private void efetuarSaque() {
        String valorTexto = JOptionPane.showInputDialog(this, "Digite o valor do saque:");

        if (valorTexto != null) {
            int valor = Integer.parseInt(valorTexto);
            mostrarMensagem(caixa.sacar(valor));
        }
    }

    private void reporCedulas() {
        String cedulaTexto = JOptionPane.showInputDialog(this, "Digite a cédula para reposição:");
        String quantidadeTexto = JOptionPane.showInputDialog(this, "Digite a quantidade:");

        if (cedulaTexto != null && quantidadeTexto != null) {
            int cedula = Integer.parseInt(cedulaTexto);
            int quantidade = Integer.parseInt(quantidadeTexto);

            mostrarMensagem(caixa.reposicaoCedulas(cedula, quantidade));
        }
    }

    private void definirCotaMinima() {
        String minimoTexto = JOptionPane.showInputDialog(this, "Digite a cota mínima:");

        if (minimoTexto != null) {
            int minimo = Integer.parseInt(minimoTexto);
            mostrarMensagem(caixa.armazenaCotaMinima(minimo));
        }
    }

    private void mostrarMensagem(String mensagem) {
        JOptionPane.showMessageDialog(this, mensagem);
    }
}